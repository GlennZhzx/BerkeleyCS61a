"""
    The strategy here will be compared with your final_strategy when you run
    python3 compare_strategies.py. It will not be submitted as part of the contest.
"""


def baseline_strategy(score, opponent_score):
    return 6